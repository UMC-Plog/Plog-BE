package com.plog.global.api.error;

import com.plog.global.api.code.BaseErrorCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;

@Getter
@RequiredArgsConstructor
public enum TaskErrorCode implements BaseErrorCode {

    ASSIGNEE_NOT_FOUND(HttpStatus.NOT_FOUND, "TASK001", "지정한 담당자를 찾을 수 없습니다."),
    ASSIGNEE_PROJECT_MISMATCH(HttpStatus.BAD_REQUEST, "TASK002", "담당자가 해당 프로젝트 소속이 아닙니다."),
    // 나간(EXIT) 멤버는 참여 팀원이 아니므로 지정 불가
    ASSIGNEE_NOT_ACTIVE(HttpStatus.BAD_REQUEST, "TASK003", "이미 프로젝트를 나간 팀원은 담당자로 지정할 수 없습니다."),
    // 담당 영역 선택지는 프로젝트 유형(개발/일반)에 따라 분류
    INVALID_CATEGORY_FOR_PROJECT_TYPE(HttpStatus.BAD_REQUEST, "TASK004", "프로젝트 유형에 맞지 않는 담당 영역입니다."),
    INVALID_ATTACHMENT(HttpStatus.BAD_REQUEST, "TASK005", "첨부 요청이 올바르지 않습니다."),
    INVALID_LINK_URL(HttpStatus.BAD_REQUEST, "TASK006", "허용되지 않는 링크입니다."),
    TASK_NOT_FOUND(HttpStatus.NOT_FOUND, "TASK007", "업무 카드를 찾을 수 없습니다."),
    TASK_ATTACHMENT_NOT_FOUND(HttpStatus.NOT_FOUND, "TASK008", "첨부파일을 찾을 수 없습니다."),
    TASK_ATTACHMENT_LIMIT_EXCEEDED(HttpStatus.BAD_REQUEST, "TASK009", "첨부파일은 최대 10개까지 등록할 수 있습니다.");

    private final HttpStatus httpStatus;
    private final String code;
    private final String message;
}