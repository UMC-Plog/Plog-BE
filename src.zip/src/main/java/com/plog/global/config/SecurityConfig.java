package com.plog.global.config;

import static org.springframework.security.config.Customizer.withDefaults;

import com.plog.global.security.jwt.JwtAccessDeniedHandler;
import com.plog.global.security.jwt.JwtAuthenticationEntryPoint;
import com.plog.global.security.jwt.JwtAuthenticationFilter;
import com.plog.global.security.jwt.MediaCookieAuthenticationFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import java.util.List;

@Configuration
public class SecurityConfig {

    private static final String[] SWAGGER_PATHS = {
            "/swagger-ui.html",
            "/swagger-ui/**",
            "/v3/api-docs/**"
    };

    // 인증 없이 접근 가능한 auth 엔드포인트 (가입/로그인/인증메일/재발급/로그아웃).
    // logout도 공개: Refresh 원문을 가진 본인만 해당 토큰을 폐기 가능하므로 Access 인증 불필요.
    // 오히려 Access 만료/탈취 상황에서 세션 폐기가 확실히 동작해야 한다.
    private static final String[] PUBLIC_AUTH_PATHS = {
            "/api/auth/email/**",
            "/api/auth/password/**",
            "/api/auth/nickname/**",
            "/api/auth/signup",
            "/api/auth/oauth/**",
            "/api/auth/login",
            "/api/auth/reissue",
            "/api/auth/logout",
            "/ws-stomp/**"
    };

    // provider OAuth/GitHub App callback은 사용자 JWT가 없으므로, 서버가 발급한 일회용 state로 검증한다.
    private static final String[] PUBLIC_INTEGRATION_CALLBACK_PATHS = {
            "/api/integrations/*/callback",
            // Notion 서버가 호출하며 JWT 대신 X-Notion-Signature로 인증한다.
            "/api/integrations/notion/events"
    };

    private final JwtAuthenticationFilter jwtAuthenticationFilter;
    private final JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint;
    private final JwtAccessDeniedHandler jwtAccessDeniedHandler;
    private final MediaCookieAuthenticationFilter mediaCookieAuthenticationFilter;

    public SecurityConfig(JwtAuthenticationFilter jwtAuthenticationFilter,
                          JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint,
                          JwtAccessDeniedHandler jwtAccessDeniedHandler,
                          MediaCookieAuthenticationFilter mediaCookieAuthenticationFilter) {
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
        this.jwtAuthenticationEntryPoint = jwtAuthenticationEntryPoint;
        this.jwtAccessDeniedHandler = jwtAccessDeniedHandler;
        this.mediaCookieAuthenticationFilter = mediaCookieAuthenticationFilter;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * .cors(withDefaults())가 참조하는 소스 빈. 이게 없으면 CORS 헤더가 안 붙어 크로스 오리진 요청이 전부 막힌다.
     * 채팅 첨부 프록시가 plog_media 쿠키(SameSite=None)를 쓰고 SockJS 도 credentials 모드로
     * 요청하므로, 허용된 Origin 에 한해 credentials 를 허용해야 한다.
     */
    @Bean
    public CorsConfigurationSource corsConfigurationSource(CorsProperties corsProperties) {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(corsProperties.allowedOrigins());
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(List.of("*"));
        config.setAllowCredentials(true);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http
                .csrf(csrf -> csrf.disable())
                .sessionManagement(session ->
                        session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers(SWAGGER_PATHS).permitAll()
                        .requestMatchers(PUBLIC_AUTH_PATHS).permitAll()
                        .requestMatchers(PUBLIC_INTEGRATION_CALLBACK_PATHS).permitAll()
                        .anyRequest().authenticated())
                .cors(withDefaults())
                .formLogin(form -> form.disable())
                .httpBasic(basic -> basic.disable())
                .exceptionHandling(handler -> handler
                        .authenticationEntryPoint(jwtAuthenticationEntryPoint)
                        .accessDeniedHandler(jwtAccessDeniedHandler))
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class)
                .addFilterAfter(mediaCookieAuthenticationFilter, JwtAuthenticationFilter.class)
                .build();
    }
}
