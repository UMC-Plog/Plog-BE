package com.plog.domain.chat.service;

import com.plog.domain.chat.dto.request.ChatMessageSendRequest.ChatMessageAttachmentRequest;
import com.plog.domain.chat.dto.request.ChatMessageSendRequest;
import com.plog.domain.chat.entity.ChatAttachment;
import com.plog.domain.chat.entity.ChatMessage;
import com.plog.domain.chat.entity.ChatRoom;
import com.plog.domain.chat.event.ChatMessageSavedEvent;
import com.plog.domain.chat.event.ChatRoomSummaryUpdatedEvent;
import com.plog.domain.chat.repository.ChatAttachmentRepository;
import com.plog.domain.chat.repository.ChatMessageRepository;
import com.plog.domain.chat.repository.ChatRoomRepository;
import com.plog.domain.chat.util.ChatMentionParser;
import com.plog.domain.notification.event.ChatMentionEvent;
import com.plog.domain.notification.event.ChatMessageNotificationEvent;
import com.plog.domain.project.entity.MemberStatus;
import com.plog.domain.project.entity.ProjectMember;
import com.plog.domain.project.repository.ProjectMemberRepository;
import com.plog.global.api.error.ChatErrorCode;
import com.plog.global.api.exception.ApiException;
import com.plog.infrastructure.s3.AttachmentPolicy;
import com.plog.infrastructure.s3.AttachmentUsage;
import jakarta.persistence.EntityManager;
import jakarta.persistence.QueryTimeoutException;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.dao.PessimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class ChatMessageAppender {

    private static final String LOCK_TIMEOUT_SQL = "SET LOCAL lock_timeout = '3s'";
    private static final int MAX_MENTION_PREVIEW_LENGTH = 100;

    private final ChatRoomRepository chatRoomRepository;
    private final ChatMessageRepository chatMessageRepository;
    private final ChatAttachmentRepository chatAttachmentRepository;
    private final ProjectMemberRepository projectMemberRepository;
    private final EntityManager entityManager;
    private final ApplicationEventPublisher eventPublisher;
    private final AttachmentPolicy attachmentPolicy;

    // PostgreSQL은 FOR UPDATE에 대기시간을 직접 못 줘서(NOWAIT 아니면 무기한 대기),
    // 트랜잭션 세션에 lock_timeout을 걸어 잠금 대기 자체를 bound 시킨다.
    // SET LOCAL이라 이 트랜잭션 종료(커밋/롤백) 시 자동 해제됨.
    private ChatRoom lockRoomForAppend(Long chatRoomId) {
        try {
            entityManager.createNativeQuery(LOCK_TIMEOUT_SQL).executeUpdate();
            return chatRoomRepository.findByIdForMessageAppend(chatRoomId)
                    .orElseThrow(() -> new ApiException(ChatErrorCode.FORBIDDEN_CHAT_ROOM_ACCESS));
        } catch (PessimisticLockingFailureException | QueryTimeoutException exception) {
            throw new ApiException(ChatErrorCode.CHAT_ROOM_LOCK_TIMEOUT, exception);
        }
    }

    // clientMessageId가 없어 멱등 대상이 아니고, 브로드캐스트 이벤트도 발행하지 않는다.
    /** 실시간 전파가 필요한 호출부라면 appendByUser로 옮기거나 별도 이벤트 발행이 필요함. **/
    @Transactional
    public ChatMessage append(Long chatRoomId, Long projectMemberId, String message) {
        ChatRoom room = lockRoomForAppend(chatRoomId);
        ProjectMember member = projectMemberRepository.findById(projectMemberId)
                .orElseThrow(() -> new ApiException(ChatErrorCode.FORBIDDEN_CHAT_ROOM_ACCESS));
        validateActiveRoomMember(room, member);

        long messageSequence = room.issueNextMessageSequence();
        return chatMessageRepository.save(
                ChatMessage.create(room, member, message, messageSequence, null)
        );
    }

    private void validateActiveRoomMember(ChatRoom room, ProjectMember member) {
        Long roomProjectId = room.getProject().getId();
        Long memberProjectId = member.getProject().getId();
        if (!roomProjectId.equals(memberProjectId) || member.getStatus() != MemberStatus.ACTIVE) {
            throw new IllegalArgumentException("ACTIVE 채팅방 멤버만 메시지를 기록할 수 있습니다.");
        }
    }

    /** WebSocket 경로 전용: STOMP Principal의 userId로 프로젝트 멤버를 찾아 메시지를 남긴다.
     *  clientMessageId로 멱등 처리하고, 커밋 후 브로드캐스트 이벤트를 발행한다.
     *  첨부는 새로 생성된 메시지에 대해서만 저장한다(멱등 히트 시 이미 저장된 첨부를 재사용)
     *  멘션 파싱/이벤트 발행도 신규 저장 시에만 수행한다(재전송 시 중복 알림 방지) */
    @Transactional
    public ChatMessage appendByUser(
            Long chatRoomId,
            Long userId,
            String clientMessageId,
            String message,
            List<ChatMessageAttachmentRequest> attachments
    ) {
        ChatRoom room = lockRoomForAppend(chatRoomId);
        ProjectMember member = projectMemberRepository
                .findByProjectIdAndUserIdAndStatus(room.getProject().getId(), userId, MemberStatus.ACTIVE)
                .orElseThrow(() -> new ApiException(ChatErrorCode.FORBIDDEN_CHAT_ROOM_ACCESS));

        Optional<ChatMessage> existing = chatMessageRepository
                .findByChatRoomIdAndProjectMemberIdAndClientMessageId(room.getId(), member.getId(), clientMessageId);
        boolean isNewMessage = existing.isEmpty();
        ChatMessage chatMessage = existing.orElseGet(() -> createAndSaveWithAttachments(
                room, member, userId, clientMessageId, message, attachments));

        // 커밋 후에만 발행됨(AFTER_COMMIT) — 재전송(멱등 히트)이어도 재브로드캐스트를 유도하기 위해 항상 발행
        eventPublisher.publishEvent(new ChatMessageSavedEvent(chatMessage.getId()));

        // 멘션 알림은 신규 저장 시에만 발행한다. 멱등 히트(재전송)까지 발행하면
        // 같은 메시지에 대해 알림이 중복 발송된다.
        if (isNewMessage) {
            List<ProjectMember> activeMembers = projectMemberRepository.findAllByProjectIdAndStatusOrderByIdAsc(
                    room.getProject().getId(), MemberStatus.ACTIVE);

            List<Long> mentionMemberIds = resolveMentionMemberIds(room, member, message);
            publishMentionEventIfAny(room, member, chatMessage, message, mentionMemberIds);

            List<Long> targetMemberIds = resolveChatMessageTargetMemberIds(activeMembers, member, mentionMemberIds);
            eventPublisher.publishEvent(new ChatMessageNotificationEvent(
                    room.getProject().getId(), room.getId(), chatMessage.getId(), member.getId(),
                    targetMemberIds, truncatePreview(message)));

            // 채팅방 목록 실시간 갱신(unreadCount/최신 메시지 미리보기)은 멘션 여부와 무관하게
            // 발신자를 제외한 참여자 전원에게 간다 — 멘션 알림(위 targetMemberIds)과는 대상 범위가 다르다.
            List<Long> participantUserIds = resolveRoomParticipantUserIds(activeMembers, member);
            String latestMessage = resolveLatestMessagePreview(message, attachments);
            eventPublisher.publishEvent(new ChatRoomSummaryUpdatedEvent(
                    room.getId(), chatMessage.getMessageSequence(), latestMessage, participantUserIds));
        }
        return chatMessage;
    }

    private List<Long> resolveMentionMemberIds(ChatRoom room, ProjectMember sender, String message) {
        Set<String> nicknameCandidates = ChatMentionParser.extractNicknameCandidates(message);
        if (nicknameCandidates.isEmpty()) {
            return List.of();
        }

        List<ProjectMember> matchedMembers = projectMemberRepository.findActiveMembersByProjectIdAndNicknameIn(
                room.getProject().getId(), MemberStatus.ACTIVE, nicknameCandidates);

        return matchedMembers.stream()
                .map(ProjectMember::getId)
                .filter(id -> !id.equals(sender.getId())) // 자기 자신 멘션 제외
                .distinct()
                .toList();
    }

    private List<Long> resolveChatMessageTargetMemberIds(
            List<ProjectMember> activeMembers,
            ProjectMember sender,
            List<Long> mentionMemberIds
    ) {
        Set<Long> excludedMemberIds = new LinkedHashSet<>(mentionMemberIds);
        excludedMemberIds.add(sender.getId());
        return activeMembers.stream()
                .map(ProjectMember::getId)
                .filter(memberId -> !excludedMemberIds.contains(memberId))
                .toList();
    }

    // 채팅방 목록 갱신 push 대상. 멘션 여부와 무관하게 발신자만 제외한 참여자 전원이다.
    private List<Long> resolveRoomParticipantUserIds(List<ProjectMember> activeMembers, ProjectMember sender) {
        return activeMembers.stream()
                .filter(activeMember -> !activeMember.getId().equals(sender.getId()))
                .map(activeMember -> activeMember.getUser().getId())
                .toList();
    }

    // 목록 미리보기 텍스트. 텍스트가 있으면 그걸 우선하고(멘션 미리보기와 동일 기준으로 자름),
    // 텍스트 없이 첨부만 있는 메시지는 첫 첨부 파일명 + (2개 이상이면 "외 N개")로 대체한다.
    private String resolveLatestMessagePreview(String message, List<ChatMessageAttachmentRequest> attachments) {
        if (message != null && !message.isBlank()) {
            return truncatePreview(message);
        }
        if (attachments == null || attachments.isEmpty()) {
            return null;
        }
        String firstFileName = attachments.get(0).fileName();
        return attachments.size() > 1
                ? firstFileName + " 외 " + (attachments.size() - 1) + "개"
                : firstFileName;
    }

    private void publishMentionEventIfAny(
            ChatRoom room,
            ProjectMember sender,
            ChatMessage chatMessage,
            String message,
            List<Long> mentionMemberIds
    ) {
        if (mentionMemberIds.isEmpty()) {
            return;
        }

        eventPublisher.publishEvent(new ChatMentionEvent(
                room.getProject().getId(),
                room.getId(),
                chatMessage.getId(),
                sender.getId(),
                mentionMemberIds,
                truncatePreview(message)
        ));
    }

    private String truncatePreview(String message) {
        if (message == null) {
            return null;
        }
        String trimmed = message.trim();
        return trimmed.length() <= MAX_MENTION_PREVIEW_LENGTH
                ? trimmed : trimmed.substring(0, MAX_MENTION_PREVIEW_LENGTH) + "…";
    }

    private ChatMessage createAndSaveWithAttachments(
            ChatRoom room,
            ProjectMember member,
            Long userId,
            String clientMessageId,
            String message,
            List<ChatMessageAttachmentRequest> attachments
    ) {
        ChatMessage chatMessage = createAndSave(room, member, clientMessageId, message);
        if (attachments.isEmpty()) {
            return chatMessage;
        }
        // 검증을 여기 두는 이유: 재전송(멱등 히트)은 이 메서드에 들어오지 않는다.
        // 바깥에서 검증하면 이미 CONFIRMED 인 첨부를 다시 확정하려다 409 로 죽는다.
        attachmentPolicy.validateCount(attachments.size(), ChatErrorCode.TOO_MANY_CHAT_ATTACHMENTS);
        List<ChatAttachment> toSave = attachments.stream()
                .map(request -> {
                    // 필드 단위 빈 값 검사는 AttachmentPolicy 가 전 도메인 공통으로 한다.
                    if (request == null) {
                        throw new ApiException(ChatErrorCode.INVALID_CHAT_ATTACHMENT);
                    }
                    return ChatAttachment.create(chatMessage,
                            attachmentPolicy.confirmFileAttachment(AttachmentUsage.CHAT, userId,
                                    request.fileName(), request.fileSize(), request.fileKey(),
                                    ChatErrorCode.INVALID_CHAT_ATTACHMENT));
                })
                .toList();
        chatAttachmentRepository.saveAll(toSave);
        return chatMessage;
    }

    // 멘션 이벤트는 appendByUser에서 isNewMessage 판정 뒤 한 번만 발행한다.
    // 여기서도 발행하면 신규 메시지 1건에 대해 이벤트가 2번 나가 알림이 중복된다.
    private ChatMessage createAndSave(ChatRoom room, ProjectMember member, String clientMessageId, String message) {
        long messageSequence = room.issueNextMessageSequence();
        return chatMessageRepository.save(
                ChatMessage.create(room, member, message, messageSequence, clientMessageId)
        );
    }
}