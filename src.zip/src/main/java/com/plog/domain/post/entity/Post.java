package com.plog.domain.post.entity;

import com.plog.domain.project.entity.ProjectMember;
import com.plog.global.common.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Getter
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Table(name = "posts")
public class Post extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "post_id")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "project_member_id", nullable = false)
    private ProjectMember projectMember;

    @Column(name = "title", nullable = false, length = 100)
    private String title;

    @Column(name = "content", nullable = false, columnDefinition = "TEXT")
    private String content;

    // ERD의 "공지 Field boolean"을 is_notice로 구체화 (팀 확인 필요)
    @Column(name = "is_notice", nullable = false)
    private boolean isNotice;

    @Column(name = "noticed_at")
    private LocalDateTime noticedAt;

    public void updateTitle(String title) {
        this.title = title;
    }

    public void updateContent(String content) {
        this.content = content;
    }

    public void changeNotice(boolean notice) {
        if (notice) {
            markAsNotice();
        } else {
            unpinNotice();
        }
    }

    public void markAsNotice() {
        this.isNotice = true;
        this.noticedAt = LocalDateTime.now(ZoneOffset.UTC);
    }

    public void unpinNotice() {
        this.isNotice = false;
    }

    public void restoreNotice() {
        this.isNotice = true;
    }
}
