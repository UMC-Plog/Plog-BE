package com.plog.domain.post.controller;

import com.plog.domain.post.dto.CommentDto;
import com.plog.domain.post.dto.PostDto;
import com.plog.domain.post.controller.docs.PostControllerDoc;
import com.plog.domain.post.service.PostService;
import com.plog.global.api.code.SuccessCode;
import com.plog.global.api.response.ApiResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
// 버전 경로 없이 /api 공통 접두사를 사용한다. AssignedApiExceptionHandler 가 지목한 "담당 API" 4개
// (Post, ProjectSettings, FcmToken, FileStorage)가 공유하는 경로 정책이고,
// JwtAuthenticationEntryPoint.isAssignedApi 가 이 경로로 401 계약(UNAUTHORIZED)을 맞춘다.
@RequestMapping("/api/projects/{projectId}/posts")
@RequiredArgsConstructor
public class PostController implements PostControllerDoc {
    private final PostService postService;

    @Override
    @PostMapping
    public ResponseEntity<ApiResponse<PostDto.CreateResponse>> createPost(
            @PathVariable Long projectId,
            @AuthenticationPrincipal Long userId,
            @Valid @RequestBody PostDto.CreateRequest request
    ) {
        return ResponseEntity.status(SuccessCode.CREATED.getHttpStatus())
                .body(ApiResponse.success(SuccessCode.CREATED, postService.createPost(projectId, userId, request)));
    }

    @Override
    @GetMapping
    public ApiResponse<PostDto.FeedResponse> getFeed(
            @PathVariable Long projectId,
            @AuthenticationPrincipal Long userId,
            @RequestParam(required = false) String cursor,
            @RequestParam(defaultValue = "20") int size
    ) {
        return ApiResponse.success(postService.getFeed(projectId, userId, cursor, size));
    }

    @Override
    @GetMapping("/notices")
    public ApiResponse<PostDto.NoticeListResponse> getNotices(
            @PathVariable Long projectId,
            @AuthenticationPrincipal Long userId
    ) {
        return ApiResponse.success(postService.getNotices(projectId, userId));
    }

    @Override
    @GetMapping("/{postId}")
    public ApiResponse<PostDto.PostResponse> getPost(
            @PathVariable Long projectId,
            @PathVariable Long postId,
            @AuthenticationPrincipal Long userId
    ) {
        return ApiResponse.success(postService.getPost(projectId, postId, userId));
    }

    @Override
    @PatchMapping("/{postId}")
    public ApiResponse<PostDto.UpdateResponse> updatePost(
            @PathVariable Long projectId,
            @PathVariable Long postId,
            @AuthenticationPrincipal Long userId,
            @Valid @RequestBody PostDto.UpdateRequest request
    ) {
        return ApiResponse.success(postService.updatePost(projectId, postId, userId, request));
    }

    @Override
    @DeleteMapping("/{postId}")
    public ApiResponse<PostDto.DeletedResponse> deletePost(
            @PathVariable Long projectId,
            @PathVariable Long postId,
            @AuthenticationPrincipal Long userId
    ) {
        return ApiResponse.success(postService.deletePost(projectId, postId, userId));
    }

    @Override
    @PatchMapping("/{postId}/notice")
    public ApiResponse<PostDto.NoticeResponse> changeNotice(
            @PathVariable Long projectId,
            @PathVariable Long postId,
            @AuthenticationPrincipal Long userId,
            @Valid @RequestBody PostDto.NoticeRequest request
    ) {
        return ApiResponse.success(postService.changeNotice(projectId, postId, userId, request));
    }

    @Override
    @PostMapping("/{postId}/comments")
    public ResponseEntity<ApiResponse<CommentDto.Response>> createComment(
            @PathVariable Long projectId,
            @PathVariable Long postId,
            @AuthenticationPrincipal Long userId,
            @Valid @RequestBody CommentDto.CreateRequest request
    ) {
        return ResponseEntity.status(SuccessCode.CREATED.getHttpStatus())
                .body(ApiResponse.success(SuccessCode.CREATED,
                        postService.createComment(projectId, postId, userId, request)));
    }

    @Override
    @GetMapping("/{postId}/comments")
    public ApiResponse<CommentDto.ListResponse> getComments(
            @PathVariable Long projectId,
            @PathVariable Long postId,
            @AuthenticationPrincipal Long userId
    ) {
        return ApiResponse.success(postService.getComments(projectId, postId, userId));
    }

    @Override
    @DeleteMapping("/{postId}/comments/{commentId}")
    public ApiResponse<PostDto.DeletedResponse> deleteComment(
            @PathVariable Long projectId,
            @PathVariable Long postId,
            @PathVariable Long commentId,
            @AuthenticationPrincipal Long userId
    ) {
        return ApiResponse.success(postService.deleteComment(projectId, postId, commentId, userId));
    }

    @Override
    @PutMapping("/{postId}/like")
    public ApiResponse<PostDto.LikeResponse> like(
            @PathVariable Long projectId,
            @PathVariable Long postId,
            @AuthenticationPrincipal Long userId
    ) {
        return ApiResponse.success(postService.like(projectId, postId, userId));
    }

    @Override
    @DeleteMapping("/{postId}/like")
    public ApiResponse<PostDto.LikeResponse> unlike(
            @PathVariable Long projectId,
            @PathVariable Long postId,
            @AuthenticationPrincipal Long userId
    ) {
        return ApiResponse.success(postService.unlike(projectId, postId, userId));
    }
}
